@echo off
title Usama Cloth House POS
set "POS_FILE=%~dp0Usama-POS.html"
set "POS_URL=file:///%POS_FILE:\=/%"

if not exist "%POS_FILE%" (
  echo Usama-POS.html isi folder mein nahi mili.
  pause
  exit /b 1
)

set "BROWSER="
for %%B in (
  "%ProgramFiles%\Google\Chrome\Application\chrome.exe"
  "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
  "%LocalAppData%\Google\Chrome\Application\chrome.exe"
  "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
  "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
) do (
  if not defined BROWSER if exist %%B set "BROWSER=%%~B"
)

if defined BROWSER (
  start "" "%BROWSER%" --app="%POS_URL%" --start-maximized
) else (
  start "" "%POS_FILE%"
)
exit /b 0
